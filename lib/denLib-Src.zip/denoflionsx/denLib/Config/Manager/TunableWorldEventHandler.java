package denoflionsx.denLib.Config.Manager;

import denoflionsx.denLib.Config.Annotations.Config;
import denoflionsx.denLib.Lib.denLib;
import denoflionsx.denLib.Mod.Handlers.WorldHandler.IdenWorldEventHandler;
import denoflionsx.denLib.Mod.denLibMod;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import net.minecraftforge.common.Configuration;

public class TunableWorldEventHandler implements IdenWorldEventHandler {

    @Override
    public void onWorldEnded() {
        for (Class c : denLibMod.tuning.getTunableClasses()) {
            Field[] f = c.getDeclaredFields();
            for (Field a : f) {
                Annotation[] anno = a.getDeclaredAnnotations();
                for (Annotation b : anno) {
                    if (b instanceof Config) {
                        denLibMod.Proxy.print("Saving tunable: " + c.getName());
                        Object o = denLib.ReflectionHelper.getStaticField(a);
                        if (o != null) {
                            if (o instanceof Configuration) {
                                Configuration config = (Configuration) o;
                                config.save();
                            }
                        }
                    }
                }
            }
        }
    }

    @Override
    public void onWorldLoaded() {
    }
}
