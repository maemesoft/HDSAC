package denoflionsx.denLib.Mod.Proxy;

import cpw.mods.fml.common.FMLLog;
import net.minecraftforge.common.MinecraftForge;

public class denLibProxy implements IdenLibProxy {

    @Override
    public void print(String msg) {
        FMLLog.info(msg);
    }

    @Override
    public void registerForgeSubscribe(Object o) {
        MinecraftForge.EVENT_BUS.register(o);
        this.print("Registered event handler.");
    }
}
