package denoflionsx.denLib.Mod.Proxy;

public interface IdenLibProxy {
    
    public void print(String msg);
    
    public void registerForgeSubscribe(Object o);
    
}
