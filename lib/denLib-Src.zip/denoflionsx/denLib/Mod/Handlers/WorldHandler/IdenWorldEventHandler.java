package denoflionsx.denLib.Mod.Handlers.WorldHandler;

public interface IdenWorldEventHandler {
    
    public void onWorldLoaded();
    
    public void onWorldEnded();
    
}
